import tkinter as tk
from tkinter import simpledialog
import hashlib

current_customer = None
products = ['remote-1500', 'fan motor-5000', 'Kids cycle-7500']
product_prices = {'remote-1500':1500, 'fan motor-5000':5000, 'Kids cycle-7500':7500}
customers = [{'name': 'animeboy', 'status': 'Active'}, {'name': 'animegirl', 'status': 'Inactive'}]
orders = [{'customer': 'animeboy', 'order': 'Order 1', 'status': 'Shipped'}, {'customer': 'animegirl', 'order': 'Order 2', 'status': 'Processing'}]

user_type = "admin"


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(stored_password, provided_password):
    return stored_password == hash_password(provided_password)


customer_passwords = {'animeboy': hash_password('josaf'),'playgirl': hash_password('levasana')}


def clear_window():
    for widget in root.winfo_children():
        widget.destroy()


def show_login_screen():
    clear_window()
    global user_type_label, login_button, switch_button, theme_button, entry_username, entry_password

    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.grid(row=0, column=0, columnspan=4, pady=10, sticky="n")

    user_type_label = tk.Label(root, text="Admin Login" if user_type == "admin" else "Customer Login", font=('Verdana', 20), bg=bg_color, fg=fg_color)
    user_type_label.grid(row=1, column=0, columnspan=4, pady=10, sticky="n")

    theme_symbol = "☀" if bg_color == "#0FFCBE" else "🌙"
    theme_button = tk.Button(root, text=theme_symbol, command=switch_theme, font=('Verdana', 10), bg=btn_color, fg=fg_color)
    theme_button.grid(row=0, column=3, padx=10, pady=10, sticky="ne")

    tk.Label(root, text="Username", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=2, column=1, padx=10, pady=2, sticky='w')
    entry_username = tk.Entry(root, font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
    entry_username.grid(row=3, column=1, columnspan=2, padx=10, pady=10, sticky='we')

    tk.Label(root, text="Password", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=4, column=1, padx=10, pady=2, sticky='w')
    entry_password = tk.Entry(root, show="*", font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
    entry_password.grid(row=5, column=1, columnspan=2, padx=10, pady=10, sticky='we')

    login_button = tk.Button(root, text="Login", command=lambda: validate_login(user_type), font=('Verdana', 16), bg=btn_color, fg=fg_color)
    login_button.grid(row=6, column=1, padx=10, pady=10, sticky="e")

    switch_button = tk.Button(root, text="Customer" if user_type == "admin" else "Admin", command=switch_user_type, font=('Verdana', 16), bg=btn_color, fg=fg_color)
    switch_button.grid(row=6, column=2, padx=10, pady=10, sticky="w")


def validate_login(user_type):
    global current_customer
    username = entry_username.get()
    password = entry_password.get()
    if user_type == "admin" and username == "Black" and password == "jojo":
        print("Admin login successful!")
        open_admin_dashboard()
    elif user_type == "customer":
        stored_password = customer_passwords.get(username)
        if stored_password and verify_password(stored_password, password):
            print("Customer login successful!")
            current_customer = username  #login aahura acc name
            open_customer_dashboard()
        else:
            print("Invalid credentials")


def switch_user_type():
    global user_type
    user_type = "customer" if user_type == "admin" else "admin"
    show_login_screen()


def on_enter(event):
    event.widget.config(bg="#6c757d")
 

def on_leave(event):
    event.widget.config(bg=btn_color)


def switch_theme():
    global bg_color, fg_color, btn_color, entry_bg_color
    if bg_color == "#282c34":
        bg_color = "#0FFCBE"
        fg_color = "#106EBE"
        btn_color = "#FFFFFF"
        entry_bg_color = "#FFFFFF"
        theme_symbol = "☀"
    else:
        bg_color = "#282c34"
        fg_color = "#61dafb"
        btn_color = "#4a4e69"
        entry_bg_color = "#3c3f41"
        theme_symbol = "🌙"

    print(f"Switching theme to {bg_color} with symbol {theme_symbol}")

    root.configure(bg=bg_color)
    for widget in root.winfo_children():
        if isinstance(widget, tk.Label):
            widget.config(bg=bg_color, fg=fg_color)
        elif isinstance(widget, tk.Entry):
            widget.config(bg=entry_bg_color, fg=fg_color)
        elif isinstance(widget, tk.Button):
            widget.config(bg=btn_color, fg=fg_color)

    theme_button.config(text=theme_symbol)
    print(f"Theme button updated to {theme_button.cget('text')}")


def on_hover_enter(event):
    event.widget.config(width=30)


def on_hover_leave(event):
    event.widget.config(width=20)


def add_product():
    product_name = simpledialog.askstring("Input", "Enter the product name:")
    if product_name:
        products.append(product_name)
        refresh_product_list()


def modify_product():
    product_name = simpledialog.askstring("Input", "Enter the product name to modify:")
    if product_name in products:
        new_name = simpledialog.askstring("Input", "Enter the new product name:")
        if new_name:
            index = products.index(product_name)
            products[index] = new_name
            refresh_product_list()
    else:
        tk.messagebox.showerror("Error", "Product not found.")


def remove_product():
    product_name = simpledialog.askstring("Input", "Enter the product name to remove:")
    if product_name in products:
        products.remove(product_name)
        refresh_product_list()
    else:
        tk.messagebox.showerror("Error", "Product not found.")


def refresh_product_list():
    product_list.delete(0, tk.END)
    for product in products:
        product_list.insert(tk.END, product)


def refresh_order_list():
    order_list.delete(0, tk.END)
    for order in orders:
        try:
            order_list.insert(tk.END, f"{order['customer']} - {order['order']} - {order['status']}")
        except KeyError as e:
            print(f"Missing key {e} in order: {order}")


def cancel_order():
    selected_order = order_list.curselection()
    if selected_order:
        order_index = selected_order[0]
        del orders[order_index]
        refresh_order_list()
    else:
        tk.messagebox.showerror("Error", "No order selected.")


def refresh_customer_list():
    customer_list.delete(0, tk.END)
    for customer in customers:
        customer_list.insert(tk.END, f"{customer['name']} - {customer['status']}")


def open_product_management():
    clear_window()
    back_button = tk.Button(root, text="←", command=open_admin_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Product Management", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    global product_list
    product_list = tk.Listbox(root, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color)
    product_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    tk.Button(root, text="Add Product", command=add_product, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Modify Product", command=modify_product, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Remove Product", command=remove_product, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)

    refresh_product_list()


def open_orders_dashboard():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)

    back_button = tk.Button(root, text="←",
                            command=open_admin_dashboard if user_type == "admin" else open_customer_dashboard,
                            font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Orders Dashboard", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    order_frame = tk.Frame(root, bg=bg_color)
    order_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    global order_list
    order_list = tk.Listbox(order_frame, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color)
    order_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    refresh_order_list()


def open_customer_dashboard():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)
    back_button = tk.Button(root, text="←", command=switch_user_type, font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)
    if user_type == "admin":
        back_button = tk.Button(root, text="←", command=open_admin_dashboard, font=('Verdana', 12), bg=btn_color,
                                fg=fg_color)
        back_button.place(x=10, y=10)
    tk.Label(root, text="Customer Dashboard", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)
    global customer_list
    customer_list = tk.Listbox(root, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color)
    customer_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    tk.Button(root, text="Browse Products", command=open_browse_products, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Order Products", command=open_order_products, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    refresh_customer_list()


def open_admin_dashboard():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)
    back_button = tk.Button(root, text="←", command=switch_user_type, font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)
    tk.Label(root, text="Admin Dashboard", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)
    tk.Button(root, text="Product Management", command=open_product_management, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Customer Dashboard", command=open_customer_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Orders Dashboard", command=open_orders_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)


def open_browse_products():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)

    back_button = tk.Button(root, text="←", command=open_customer_dashboard, font=('Verdana', 12), bg=btn_color,
                            fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Browse Products", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    global product_list
    product_list = tk.Listbox(root, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color)
    product_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    refresh_product_list()


def open_order_products():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)

    back_button = tk.Button(root, text="←",
                            command=open_customer_dashboard,
                            font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Order Products", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    order_frame = tk.Frame(root, bg=bg_color)
    order_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    global product_entries
    product_entries = []

    for row, product in enumerate(products):
        product_label = tk.Label(order_frame, text=product, font=('Verdana', 12), bg=bg_color, fg=fg_color)
        product_label.grid(row=row, column=0, padx=5, pady=5, sticky='w')

        quantity_var = tk.StringVar(value='0')
        quantity_entry = tk.Entry(order_frame, textvariable=quantity_var, font=('Verdana', 12), width=5,
                                  bg=entry_bg_color, fg=fg_color)
        quantity_entry.grid(row=row, column=1, padx=5, pady=5, sticky='e')

        quantity_var.trace('w', lambda *args: update_total_price())
        product_entries.append((product, quantity_var))

    global total_price_label
    total_price_label = tk.Label(root, text="Total: $0", font=('Verdana', 16), bg=bg_color, fg=fg_color)
    total_price_label.pack(pady=10)

    # discount admin ku
    if user_type == "admin":
        discount_label = tk.Label(root, text="5% discount applied for Admins", font=('Verdana', 12), bg=bg_color,
                                  fg=fg_color)
        discount_label.pack(pady=5)

    tk.Button(root, text="Submit Order", command=submit_order, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(
        pady=10)

    update_total_price()


def calculate_total_amount():
    total = 0
    for product, quantity_var in product_entries:
        quantity = int(quantity_var.get())
        if quantity > 0:
            total += quantity * product_prices[product]
    if user_type == "admin":
        total *= 0.95
    return total


def update_total_price():
    total_price = calculate_total_amount()
    total_price_label.config(text=f"Total: ${total_price}")


def submit_order():
    global orders
    order_details = []
    for product, quantity_var in product_entries:
        quantity = int(quantity_var.get())
        if quantity > 0:
            order_details.append({'product': product, 'quantity': quantity})
    total_amount = calculate_total_amount()
    orders.append({'customer': current_customer, 'details': order_details, 'total': total_amount})
    print(f"Order submitted: {order_details}")
    print(f"Total amount: {total_amount}")


# content center panna and gui
root = tk.Tk()
root.title("Login Page")
root.geometry('800x600')
bg_color = "#282c34"
fg_color = "#61dafb"
btn_color = "#4a4e69"
entry_bg_color = "#3c3f41"
root.configure(bg=bg_color)
root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(11, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
root.grid_columnconfigure(3, weight=1)

show_login_screen()


name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
name_label.grid(row=0, column=0, columnspan=4, pady=10, sticky="n")

theme_symbol = "☀" if bg_color == "#0FFCBE" else "🌙"
theme_button = tk.Button(root, text=theme_symbol, command=switch_theme, font=('Verdana', 10), bg=btn_color, fg=fg_color)
theme_button.grid(row=0, column=3, padx=10, pady=10, sticky="ne")

user_type_label = tk.Label(root, text="Admin Login", font=('Verdana', 20), bg=bg_color, fg=fg_color)
user_type_label.grid(row=1, column=0, columnspan=4, pady=10, sticky="n")

tk.Label(root, text="Username", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=2, column=1, padx=10, pady=2,
                                                                                     sticky='w')
entry_username = tk.Entry(root, font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
entry_username.grid(row=3, column=1, columnspan=2, padx=10, pady=10, sticky='we')

tk.Label(root, text="Password", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=4, column=1, padx=10, pady=2,
                                                                                     sticky='w')
entry_password = tk.Entry(root, show="*", font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
entry_password.grid(row=5, column=1, columnspan=2, padx=10, pady=10, sticky='we')

login_button = tk.Button(root, text="Login", command=lambda: validate_login("admin"), font=('Verdana', 16),
                         bg=btn_color, fg=fg_color)
login_button.grid(row=6, column=1, padx=10, pady=10, sticky="e")

switch_button = tk.Button(root, text="Customer", command=switch_user_type, font=('Verdana', 16), bg=btn_color,
                          fg=fg_color)
switch_button.grid(row=6, column=2, padx=10, pady=10, sticky="w")

# hover effects bind panradhuku
entry_username.bind("<Enter>", on_hover_enter)
entry_username.bind("<Leave>", on_hover_leave)
entry_password.bind("<Enter>", on_hover_enter)
entry_password.bind("<Leave>", on_hover_leave)

login_button.bind("<Enter>", on_enter)
login_button.bind("<Leave>", on_leave)
switch_button.bind("<Enter>", on_enter)
switch_button.bind("<Leave>", on_leave)
theme_button.bind("<Enter>", on_enter)
theme_button.bind("<Leave>", on_leave)


root.mainloop()